import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Handles the display of session information, session duration, and user details after logout.
 */
public class lastpage extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        
        try (PrintWriter out = response.getWriter()) {
            // Get session and username attribute
            HttpSession session = request.getSession();
            String username = "";
            if (session != null && session.getAttribute("username") != null) {
                username = (String) session.getAttribute("username");

                // Calculate session duration
                long durationMillis = System.currentTimeMillis() - session.getCreationTime();
                long durationSeconds = durationMillis / 1000; // Convert milliseconds to seconds
                long durationMinutes = durationSeconds / 60; // Convert seconds to minutes
                long remainingSeconds = durationSeconds % 60; // Get the remaining seconds
                
                // Invalidate the session after getting the necessary information
                session.invalidate();
                
                // Output the HTML response
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Session Info</title>");
                out.println("<style>");
                out.println("body { font-family: Arial, sans-serif; background-color: #f7f7f7; padding: 50px; text-align: center; }");
                out.println(".container { background-color: #fff; border-radius: 8px; padding: 20px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); width: 300px; margin: 0 auto; }");
                out.println("table { width: 100%; border-collapse: collapse; }");
                out.println("td { padding: 10px; text-align: left; }");
                out.println("button { background-color: #008C8A; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; }");
                out.println("button:hover { background-color: #006D6A; }");
                out.println("</style>");
                out.println("</head>");
                out.println("<body>");

                out.println("<div class='container'>");
                out.println("<h2>Thank you, " + username + "</h2>");
                out.println("<p>Your session has ended. Below is your session information:</p>");
                out.println("<table>");
                out.println("<tr><td>Session Duration</td><td>" + durationMinutes + " minutes and " + remainingSeconds + " seconds</td></tr>");
                out.println("</table>");
                out.println("<form action='logout' method='post'>");
                out.println("<button type='submit'>Go to Logout</button>");
                out.println("</form>");
                out.println("</div>");

                out.println("</body>");
                out.println("</html>");
            } else {
                out.println("<html><body><h2>No active session found. Please log in first.</h2></body></html>");
            }
        }
    }

    // Handles GET requests
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    // Handles POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Handles session duration display and user info after logout.";
    }
}
