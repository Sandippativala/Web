import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Handles user logout, displays session information and access count.
 */
public class logout extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");

        // Get the session
        HttpSession session = request.getSession();
        String username = "";
        Integer count = 0;
        
        // Check if session and username attribute exist
        if (session != null && session.getAttribute("username") != null) {
            username = (String) session.getAttribute("username");
            // Handle access count
            count = (Integer) session.getAttribute("count");
            if (count == null) {
                count = 1;
            } else {
                count++;
            }
            session.setAttribute("count", count); // Update count
        }

        // Get session details
        String sessionId = session.getId();
        Date creationTime = new Date(session.getCreationTime());
        Date lastAccessedTime = new Date(session.getLastAccessedTime());

        // Generate the response HTML
        try (PrintWriter out = response.getWriter()) {
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Logout - Session Info</title>");
            out.println("<style>");
            out.println("body {font-family: 'Arial', sans-serif; background-color: #e0f7fa; color: #333; margin: 0; padding: 0; display: flex; justify-content: center; align-items: center; height: 100vh;}");
            out.println(".container { background-color: #fff; border-radius: 12px; padding: 30px; width: 450px; text-align: center; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);}");
            out.println("h2 { color: #00796b; }");
            out.println("table { width: 100%; margin: 20px 0; border-collapse: collapse; text-align: left; }");
            out.println("td { padding: 10px; }");
            out.println("tr:nth-child(even) { background-color: #f1f1f1; }");
            out.println("button { background-color: #00796b; color: white; padding: 12px 20px; border: none; border-radius: 5px; cursor: pointer; transition: background-color 0.3s ease; width: 100%; font-size: 16px; margin-top: 20px; }");
            out.println("button:hover { background-color: #004d40; }");
            out.println("footer { margin-top: 30px; font-size: 14px; color: #777; }");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");

            // Main content with user info and session details
            out.println("<div class='container'>");
            out.println("<h2>Goodbye, " + username + "!</h2>");
            out.println("<p>You have visited us <strong>" + count + "</strong> times.</p>");
            out.println("<h3>Session Details</h3>");
            out.println("<table>");
            out.println("<tr><td>Session ID</td><td>" + sessionId + "</td></tr>");
            out.println("<tr><td>Creation Time</td><td>" + creationTime + "</td></tr>");
            out.println("<tr><td>Last Accessed Time</td><td>" + lastAccessedTime + "</td></tr>");
            out.println("</table>");

            // Logout button
            out.println("<form action='logout' method='post'>");
            out.println("<button type='submit'>Logout</button>");
            out.println("</form>");

            out.println("<footer>");
            out.println("<p>Thanks for visiting!</p>");
            out.println("</footer>");

            out.println("</div>");

            out.println("</body>");
            out.println("</html>");
        }
    }

    // Handles GET requests
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    // Handles POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Handles the logout process and displays session information.";
    }
}
