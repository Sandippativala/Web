import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class viewdata extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            Connection con;
            PreparedStatement ps;
            ResultSet rs;
            HttpSession session = request.getSession();
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java_db", "root", "");

            // Fetch data from the emp table
            ps = con.prepareStatement("SELECT * FROM emp");
            rs = ps.executeQuery();

            // Store the result set in session
            session.setAttribute("empData", rs);

            // Begin HTML output
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Employee Data</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<center>");
            out.println("<div class='main'>");
            out.println("<table border='1' cellpadding='10'>");
            out.println("<tr>");
            out.println("<th>ID</th>");
            out.println("<th>Name</th>");
            out.println("<th>Date of Birth</th>");
            out.println("<th>Date of Joining</th>");
            out.println("<th>Contact Number</th>");
            out.println("<th>Action</th>");
            out.println("</tr>");
            
            // Display fetched data in HTML table
            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>" + rs.getInt("empno") + "</td>");
                out.println("<td>" + rs.getString("ename") + "</td>");
                out.println("<td>" + rs.getString("dob") + "</td>");
                out.println("<td>" + rs.getString("jod") + "</td>");
                out.println("<td>" + rs.getString("contactno") + "</td>");
                out.println("<td>");
                out.println("<a href='update.jsp?empno=" + rs.getInt("empno") + "'>Edit</a>");
                out.println(" | ");
                out.println("<a href='delete_data?empno=" + rs.getInt("empno") + "'>Delete</a>");
                out.println("</td>");
                out.println("</tr>");
            }
            
            // End HTML output
            out.println("</table>");
            out.println("</div>");
            out.println("</center>");
            out.println("</body>");
            out.println("</html>");
            
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Exception: " + ex.getMessage());
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
