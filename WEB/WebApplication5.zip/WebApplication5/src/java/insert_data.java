import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.logging.Level;
import java.util.logging.Logger;

public class insert_data extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(insert_data.class.getName());

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
          
            String empno = request.getParameter("empno");
            String ename = request.getParameter("ename");
            String dob = request.getParameter("dob");
            String jod = request.getParameter("jod");
            String contactno = request.getParameter("contactno");

            Connection con = null;
            PreparedStatement ps = null;
            ResultSet rs = null;

            try {
              
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java_db", "root", "");

                ps = con.prepareStatement("SELECT * FROM emp WHERE empno = ?");
                ps.setString(1, empno);
                rs = ps.executeQuery();
                if (rs.next()) {
                    out.println("<script>");
                    out.println("alert('Employee Number already exists. Please use a different one.');");
                    out.println("window.location='index.jsp';");
                    out.println("</script>");
                } else {
                    ps = con.prepareStatement("INSERT INTO emp (empno, ename, dob, jod, contactno) VALUES (?, ?, ?, ?, ?)");
                    ps.setString(1, empno);
                    ps.setString(2, ename);
                    ps.setString(3, dob);
                    ps.setString(4, jod);
                    ps.setString(5, contactno);
                    ps.executeUpdate();
                    
                    response.sendRedirect("viewdata");
                }
            } catch (ClassNotFoundException | SQLException e) {
                LOGGER.log(Level.SEVERE, "Database error: ", e);
                out.println("<script>");
                out.println("alert('An error occurred while processing your request.');");
                out.println("window.location='index.jsp';");
                out.println("</script>");
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (ps != null) ps.close();
                    if (con != null) con.close();
                } catch (SQLException e) {
                    LOGGER.log(Level.SEVERE, "Error closing resources: ", e);
                }
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
