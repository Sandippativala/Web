import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class update_data extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(update_data.class.getName());

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String empno = request.getParameter("empno");
        String ename = request.getParameter("ename");
        String dob = request.getParameter("dob");
        String jod = request.getParameter("jod");
        String contactno = request.getParameter("contactno");

        Connection con = null;
        PreparedStatement ps = null;

        try (PrintWriter out = response.getWriter()) {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection to the database
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java_db", "root", "");

            // Prepare SQL statement for updating employee data
            ps = con.prepareStatement("UPDATE emp SET ename=?, dob=?, jod=?, contactno=? WHERE empno=?");
            ps.setString(1, ename);
            ps.setString(2, dob);
            ps.setString(3, jod);
            ps.setString(4, contactno);
            ps.setString(5, empno);

            // Execute the update query
            ps.executeUpdate();

            // Redirect to the view data page after update
            response.sendRedirect("viewdata?done=true");

        } catch (ClassNotFoundException | SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error during database update", ex);

            // Show error message on failure
            try (PrintWriter out = response.getWriter()) {
                out.println("<script>");
                out.println("alert('An error occurred while updating the data.');");
                out.println("window.location='index.jsp';");
                out.println("</script>");
            }

        } finally {
            // Close resources in the finally block to avoid memory leaks
            try {
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException ex) {
                LOGGER.log(Level.SEVERE, "Error closing resources", ex);
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet for updating employee data in the database";
    }
}
