import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet to delete employee data from the database.
 */
public class delete_data extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(delete_data.class.getName());

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        // Parse employee number from request parameters
        String empnoStr = request.getParameter("empno");

        if (empnoStr != null && !empnoStr.isEmpty()) {
            try {
                int empno = Integer.parseInt(empnoStr); // Convert empno to integer

                Connection con = null;
                PreparedStatement ps = null;

                try {
                    // Load MySQL JDBC Driver
                    Class.forName("com.mysql.cj.jdbc.Driver");

                    // Establish the connection to the database
                    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java_db", "root", "");

                    // Prepare SQL statement for deleting employee data
                    ps = con.prepareStatement("DELETE FROM emp WHERE empno = ?");
                    ps.setInt(1, empno);

                    // Execute the deletion
                    int rowsAffected = ps.executeUpdate();

                    // Check if any row was deleted
                    if (rowsAffected > 0) {
                        // Redirect to the viewdata page after successful deletion
                        response.sendRedirect("viewdata?done=true");
                    } else {
                        // If no rows were affected, notify the user
                        response.sendRedirect("viewdata?error=true");
                    }

                } catch (ClassNotFoundException | SQLException ex) {
                    LOGGER.log(Level.SEVERE, "Error during database operation", ex);

                    // Show an error alert if an exception occurs
                    try (PrintWriter out = response.getWriter()) {
                        out.println("<script>");
                        out.println("alert('An error occurred while deleting the data.');");
                        out.println("window.location='index.jsp';");
                        out.println("</script>");
                    }

                } finally {
                    // Close the database resources in the finally block
                    try {
                        if (ps != null) ps.close();
                        if (con != null) con.close();
                    } catch (SQLException ex) {
                        LOGGER.log(Level.SEVERE, "Error closing resources", ex);
                    }
                }

            } catch (NumberFormatException e) {
                // Handle invalid empno format (non-integer)
                LOGGER.log(Level.SEVERE, "Invalid empno format", e);
                response.sendRedirect("viewdata?error=true");
            }
        } else {
            // If empno is missing or empty, redirect with error
            response.sendRedirect("viewdata?error=true");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet to delete employee data from the database";
    }
}
